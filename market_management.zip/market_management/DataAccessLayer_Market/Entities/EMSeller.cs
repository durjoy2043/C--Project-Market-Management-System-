﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer_Market.Entities
{
   public  class EMSeller
    {
 

        private string sellerPhone;
        private string sellerName;
        private string sellerpass;
      
        public string SellerPhone { get; set; }
        public string SellerName { get; set; }
        public string Sellerpass { get; set; }





    }
}
